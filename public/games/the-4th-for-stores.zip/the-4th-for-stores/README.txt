The 4th — store copy
Waterman College / The Good Feet Store  ·  DFW 2024 photos

How to open
1. Unzip this folder.
2. Double-click index.html. It opens in Chrome, Edge, or Safari.
3. You do not need to log in. Progress saves on that computer.

What's in this build
- Ground Force (golf Strengthener — the SLS chassis, named for the course)
- W.W.K.D. (What Would Karen Do) with high / average / flat arch
- Official DFW 2024 catalog photos
- PLACE, leftover 4th, Never-this, floor rounds

Photo fixes in this pack
- Deluxe is the tan / caramel pair with the deep heel cup (it was showing Clear Flex)
- Deluxe Plus is the Deluxe family — same official Deluxe shot
- Flex is the official two-tone Flex (white top, tan underside)
- Mid-Flex is the official black pair
- Ground Force uses the SLS photo — same chassis, golf positioning
- Leather covers are not in this line

Talk rules that still stand
- Gym, run, court = Sports Maintainer. Never a Strengthener.
- Golf = heel counter. Name Ground Force. Never swing / distance / handicap claims.
- Dress + ball of foot = SLS, then SLM. Name SLS in dress, Ground Force on the course.

Photos and marks from DFW Product Knowledge 2024, the R5 Lifestyle / Activity chart, and the Ground Force talk guide.
